var x =18;
var y =81;
z = x <=y;
document.getElementById('res').innerHTML =z;
var _j="Welcome to SK Website";
alert(_j);
  
document.write().innerHTML="<h1>Welcome To SK Website</h1>";